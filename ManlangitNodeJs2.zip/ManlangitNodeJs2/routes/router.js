const express = require('express');
const router = express.Router();
const controller = require('../controller/AppController');

router.get('/', controller.index);
router.get('/404', controller.error);
router.get('/about', controller.about);
router.get('/blog', controller.blog);
router.get('/contact', controller.contact);
router.get('/project', controller.project);
router.get('/service', controller.service);
router.get('/team', controller.team);
router.get('/testimonial', controller.testimonial);



module.exports = router;